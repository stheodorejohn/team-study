'use client'

/**
 * ScriptureModal – accessible dialog for reading a passage.
 *
 * Accessibility checklist:
 *  ✅ role="dialog" + aria-modal="true" + aria-labelledby
 *  ✅ Focus trapped to the dialog on open
 *  ✅ Escape key closes the dialog
 *  ✅ Return focus to trigger on close
 *  ✅ Backdrop click closes the dialog
 *  ✅ print:hidden so it never appears in PDF exports
 */

import { useEffect, useRef } from 'react'
import { X, BookOpen } from 'lucide-react'

interface ScriptureModalProps {
  /** Section title shown as the dialog heading */
  sectionTitle: string
  scriptureReference: string | null
  summary: string | null
  scriptureText: string | null
  /** Element that triggered the modal — focus returns here on close */
  triggerRef?: React.RefObject<HTMLElement | null>
  onClose: () => void
}

export function ScriptureModal({
  sectionTitle,
  scriptureReference,
  summary,
  scriptureText,
  triggerRef,
  onClose,
}: ScriptureModalProps) {
  const dialogRef = useRef<HTMLDivElement>(null)
  const closeButtonRef = useRef<HTMLButtonElement>(null)
  const headingId = 'scripture-modal-heading'

  // ── Focus the close button when the dialog opens ──
  useEffect(() => {
    closeButtonRef.current?.focus()
  }, [])

  // ── Escape key listener ──
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        e.preventDefault()
        handleClose()
      }
    }
    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // ── Basic focus trap (Tab / Shift+Tab stays inside dialog) ──
  useEffect(() => {
    const dialog = dialogRef.current
    if (!dialog) return

    const focusable = dialog.querySelectorAll<HTMLElement>(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    )
    const first = focusable[0]
    const last = focusable[focusable.length - 1]

    function trapFocus(e: KeyboardEvent) {
      if (e.key !== 'Tab') return
      if (e.shiftKey) {
        if (document.activeElement === first) {
          e.preventDefault()
          last?.focus()
        }
      } else {
        if (document.activeElement === last) {
          e.preventDefault()
          first?.focus()
        }
      }
    }

    dialog.addEventListener('keydown', trapFocus)
    return () => dialog.removeEventListener('keydown', trapFocus)
  }, [])

  function handleClose() {
    onClose()
    // Return focus to the trigger element
    triggerRef?.current?.focus()
  }

  return (
    /* Outer portal wrapper — print:hidden ensures it never shows in PDFs */
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 print:hidden"
      aria-hidden="false"
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        aria-hidden="true"
        onClick={handleClose}
      />

      {/* Dialog panel */}
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={headingId}
        className="relative z-10 w-full max-w-lg max-h-[85vh] flex flex-col rounded-2xl bg-gray-900 border border-gray-700 shadow-2xl overflow-hidden"
      >
        {/* ── Header ── */}
        <div className="flex items-start justify-between gap-3 px-5 pt-5 pb-4 border-b border-gray-800 flex-shrink-0">
          <div className="flex items-start gap-3 min-w-0">
            <div className="mt-0.5 flex-shrink-0 inline-flex items-center justify-center h-8 w-8 rounded-lg bg-indigo-600/20 border border-indigo-500/30">
              <BookOpen className="h-4 w-4 text-indigo-400" aria-hidden="true" />
            </div>
            <div className="min-w-0">
              <h2
                id={headingId}
                className="text-base font-bold text-gray-100 leading-snug"
              >
                {sectionTitle}
              </h2>
              {scriptureReference && (
                <p className="text-sm text-indigo-400 mt-0.5 font-medium">
                  {scriptureReference}
                </p>
              )}
            </div>
          </div>

          <button
            ref={closeButtonRef}
            type="button"
            onClick={handleClose}
            aria-label="Close scripture modal"
            className="flex-shrink-0 rounded-lg p-1.5 text-gray-500 hover:text-gray-200 hover:bg-gray-800 transition-colors"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        {/* ── Scrollable body ── */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-5">
          {/* Summary block */}
          {summary && (
            <section aria-label="Summary">
              <h3 className="text-xs font-semibold uppercase tracking-widest text-gray-500 mb-2">
                Summary
              </h3>
              <p className="text-sm text-gray-300 leading-relaxed">{summary}</p>
            </section>
          )}

          {/* Scripture text */}
          {scriptureText ? (
            <section aria-label="Scripture passage">
              <h3 className="text-xs font-semibold uppercase tracking-widest text-gray-500 mb-2">
                Passage
              </h3>
              <div className="rounded-xl bg-gray-800/60 border border-gray-700/50 px-4 py-4">
                <p className="text-sm text-gray-200 leading-8 whitespace-pre-wrap font-serif">
                  {scriptureText}
                </p>
              </div>
            </section>
          ) : (
            <p className="text-sm text-gray-600 italic text-center py-4">
              No passage text added yet.
            </p>
          )}
        </div>

        {/* ── Footer ── */}
        <div className="px-5 py-4 border-t border-gray-800 flex justify-end flex-shrink-0">
          <button
            type="button"
            onClick={handleClose}
            className="rounded-xl bg-gray-800 hover:bg-gray-700 transition-colors px-4 py-2 text-sm font-medium text-gray-200"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  )
}

'use client'

/**
 * FlipBookViewer – react-pageflip powered study-guide book
 *
 * Architecture:
 *  • Flat "pages" array built from StudyMaterial (cover → sections → back)
 *  • Questions split into chunks of 3 per page
 *  • ForwardRef <Page> wrapper required by react-pageflip
 *  • showPageCorners + corner affordance overlays for click-to-flip
 *  • Prev / Next buttons + page counter at the bottom
 *  • Print layout is a simple stacked version (no flipbook in PDF)
 *  • Answer state lives here; persisted to localStorage by slug
 */

import React, {
  forwardRef,
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo,
} from 'react'
import HTMLFlipBook from 'react-pageflip'
import {
  ChevronLeft,
  ChevronRight,
  BookOpen,
  Printer,
  RotateCcw,
} from 'lucide-react'
import type { StudyMaterial, StudySection, Question } from '@/lib/supabase'
import { ScriptureModal } from '@/components/ScriptureModal'

// ─── Answer state ─────────────────────────────────────────────────────────────

type AnswerMap = Record<string, string | string[]>

function storageKey(slug: string) {
  return `study_answers_${slug}`
}

// ─── Page data model ──────────────────────────────────────────────────────────

type CoverPageData = { kind: 'cover'; material: StudyMaterial }
type SectionHeaderData = { kind: 'section-header'; section: StudySection; sectionIdx: number; total: number }
type QuestionsPageData = { kind: 'questions'; section: StudySection; sectionIdx: number; questions: Question[]; partNum: number; totalParts: number }
type BlankPageData = { kind: 'blank' }
type BackPageData = { kind: 'back'; material: StudyMaterial }

type PageData = CoverPageData | SectionHeaderData | QuestionsPageData | BlankPageData | BackPageData

function chunk<T>(arr: T[], size: number): T[][] {
  const out: T[][] = []
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size))
  return out
}

function buildPages(material: StudyMaterial): PageData[] {
  const pages: PageData[] = []
  pages.push({ kind: 'cover', material })

  material.study_sections.forEach((section, si) => {
    pages.push({
      kind: 'section-header',
      section,
      sectionIdx: si,
      total: material.study_sections.length,
    })

    const chunks = chunk(section.questions, 3)
    chunks.forEach((qs, ci) =>
      pages.push({
        kind: 'questions',
        section,
        sectionIdx: si,
        questions: qs,
        partNum: ci + 1,
        totalParts: chunks.length,
      })
    )
  })

  pages.push({ kind: 'back', material })

  return pages
}

// Section accent colours (cycles)
const ACCENTS = [
  '#4F46E5', '#7C3AED', '#0EA5E9',
  '#10B981', '#F59E0B', '#EC4899',
]
function accent(idx: number) {
  return ACCENTS[idx % ACCENTS.length]
}

// ─── ForwardRef page wrapper (required by react-pageflip) ─────────────────────

interface PageProps {
  children: React.ReactNode
  pageNum?: number
  totalPages?: number
  density?: 'hard' | 'soft'
}

const Page = forwardRef<HTMLDivElement, PageProps>(
  ({ children, pageNum, totalPages, density = 'soft' }, ref) => (
    <div
      ref={ref}
      data-density={density}
      className="relative bg-white overflow-hidden"
      style={{ height: '100%', width: '100%' }}
    >
      {children}
      {/* Page number footer */}
      {pageNum !== undefined && (
        <div className="absolute bottom-2 inset-x-0 text-center text-[10px] text-gray-300 pointer-events-none">
          {pageNum} / {totalPages}
        </div>
      )}
    </div>
  )
)
Page.displayName = 'Page'

// ─── Page content components ──────────────────────────────────────────────────

function CoverContent({ material }: { material: StudyMaterial }) {
  return (
    <div
      className="h-full w-full flex flex-col justify-between px-7 py-8"
      style={{
        background: 'linear-gradient(160deg, #1e1b4b 0%, #312e81 50%, #4c1d95 100%)',
      }}
    >
      {/* Top ornament */}
      <div className="flex flex-col items-center gap-1">
        <BookOpen className="h-9 w-9 text-indigo-300 opacity-70" aria-hidden />
        {material.organization && (
          <p className="text-xs text-indigo-300 font-medium tracking-widest uppercase mt-1">
            {material.organization}
          </p>
        )}
      </div>

      {/* Centre title */}
      <div className="space-y-3 text-center">
        <h1 className="text-2xl font-extrabold text-white leading-tight tracking-tight">
          {material.title}
        </h1>
        {material.subtitle && (
          <p className="text-sm text-indigo-200 leading-relaxed">{material.subtitle}</p>
        )}
      </div>

      {/* Memory verse */}
      {material.memory_verse && (
        <div className="rounded-xl bg-white/10 backdrop-blur-sm border border-white/10 px-4 py-3">
          <p className="text-[10px] font-semibold text-indigo-300 uppercase tracking-widest mb-1">
            Memory Verse
          </p>
          <p className="text-xs text-indigo-100 italic leading-relaxed">
            {material.memory_verse}
          </p>
        </div>
      )}

      <p className="text-center text-[10px] text-indigo-400">Drag corners or tap edges to turn pages →</p>
    </div>
  )
}

function SectionHeaderContent({
  section,
  sectionIdx,
  total,
  onOpenModal,
}: {
  section: StudySection
  sectionIdx: number
  total: number
  onOpenModal: () => void
}) {
  const color = accent(sectionIdx)
  const hasPassage = !!(section.scripture_reference || section.scripture_text || section.summary)

  return (
    <div className="h-full flex flex-col">
      {/* Coloured top band */}
      <div
        className="px-6 pt-6 pb-5 flex-shrink-0"
        style={{ background: `linear-gradient(135deg, ${color}22, ${color}11)` }}
      >
        <span
          className="inline-block rounded-full px-2.5 py-0.5 text-[10px] font-bold tracking-widest uppercase mb-3"
          style={{ background: `${color}22`, color }}
        >
          Section {sectionIdx + 1} of {total}
        </span>
        <h2 className="text-xl font-extrabold text-gray-900 leading-tight">
          {section.title}
        </h2>
        {section.scripture_reference && (
          <p className="text-xs text-gray-500 italic mt-1">{section.scripture_reference}</p>
        )}
      </div>

      {/* Body */}
      <div className="flex-1 px-6 py-5 flex flex-col gap-4">
        {section.summary && (
          <p className="text-xs text-gray-600 leading-relaxed">{section.summary}</p>
        )}

        {hasPassage && (
          <button
            type="button"
            onClick={onOpenModal}
            className="self-start inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors"
            style={{
              borderColor: `${color}50`,
              color,
              background: `${color}10`,
            }}
          >
            📖 Read Passage
          </button>
        )}

        <div className="flex-1 flex items-end">
          <p className="text-xs text-gray-400 italic">
            Turn the page to begin answering →
          </p>
        </div>
      </div>

      {/* Bottom accent bar */}
      <div className="h-1 w-full" style={{ background: `linear-gradient(90deg, ${color}, transparent)` }} />
    </div>
  )
}


function QuestionInput({
  question,
  answersRef,
  onStringAnswer,
  onCheckboxToggle,
}: {
  question: Question
  answersRef: React.MutableRefObject<AnswerMap>
  onStringAnswer: (id: string, v: string) => void
  onCheckboxToggle: (id: string, opt: string, checked: boolean) => void
}) {
  const base =
    'w-full rounded border border-gray-200 bg-gray-50 px-2 py-1.5 text-xs text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-indigo-400 transition'

  const stopDrag = (e: React.SyntheticEvent) => e.stopPropagation()

  return (
    <div className="space-y-1">
      <label className="block text-xs font-medium text-gray-700 leading-snug">
        {question.prompt}
        {question.is_required && <span className="text-red-400 ml-0.5">*</span>}
      </label>

      {/* 
        Industry standard fix for flipbooks:
        Stop all drag-initiating events from bubbling up to the flip engine,
        so it doesn't call preventDefault() and steal focus.
      */}
      <div 
        onMouseDown={stopDrag} 
        onTouchStart={stopDrag} 
        onPointerDown={stopDrag}
        style={{ userSelect: 'text', WebkitUserSelect: 'text' }}
      >
        {(question.type === 'text' || question.type === 'textarea') && (
          <textarea
            defaultValue={(answersRef.current[question.id] as string) ?? ''}
            placeholder="Answer…"
            rows={3}
            onChange={(e) => onStringAnswer(question.id, e.target.value)}
            className={`${base} min-h-[72px] resize-y`}
          />
        )}

        {question.type === 'radio' && (
          <div className="space-y-1">
            {(question.options ?? []).map((opt, i) => (
              <label key={i} className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="radio"
                  name={`q-${question.id}`}
                  value={opt}
                  defaultChecked={(answersRef.current[question.id] as string) === opt}
                  onChange={() => onStringAnswer(question.id, opt)}
                  className="h-3 w-3 text-indigo-600"
                />
                <span className="text-xs text-gray-600">{opt}</span>
              </label>
            ))}
          </div>
        )}

        {question.type === 'checkbox' && (
          <div className="space-y-1">
            {(question.options ?? []).map((opt, i) => (
              <label key={i} className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  value={opt}
                  defaultChecked={((answersRef.current[question.id] as string[]) ?? []).includes(opt)}
                  onChange={(e) => onCheckboxToggle(question.id, opt, e.target.checked)}
                  className="h-3 w-3 rounded text-indigo-600"
                />
                <span className="text-xs text-gray-600">{opt}</span>
              </label>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function QuestionsPageContent({
  section,
  sectionIdx,
  questions,
  partNum,
  totalParts,
  answersRef,
  onStringAnswer,
  onCheckboxToggle,
}: {
  section: StudySection
  sectionIdx: number
  questions: Question[]
  partNum: number
  totalParts: number
  answersRef: React.MutableRefObject<AnswerMap>
  onStringAnswer: (id: string, v: string) => void
  onCheckboxToggle: (id: string, opt: string, checked: boolean) => void
}) {
  const color = accent(sectionIdx)

  return (
    <div className="h-full flex flex-col px-5 py-4">
      {/* Mini section header */}
      <div className="flex items-center gap-2 mb-3 flex-shrink-0 pb-2 border-b border-gray-100">
        <div className="h-2.5 w-2.5 rounded-full flex-shrink-0" style={{ background: color }} />
        <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider truncate">
          {section.title}
        </span>
        {totalParts > 1 && (
          <span className="ml-auto text-[10px] text-gray-300 flex-shrink-0">
            {partNum}/{totalParts}
          </span>
        )}
      </div>

      {/* Questions */}
      <div className="flex-1 space-y-4 overflow-y-auto pr-1">
        {questions.map((q, i) => (
          <QuestionInput
            key={q.id}
            question={q}
            answersRef={answersRef}
            onStringAnswer={onStringAnswer}
            onCheckboxToggle={onCheckboxToggle}
          />
        ))}
      </div>
    </div>
  )
}

function BackContent({ material }: { material: StudyMaterial }) {
  return (
    <div
      className="h-full flex flex-col items-center justify-center gap-5 px-6 text-center"
      style={{
        background: 'linear-gradient(160deg, #0f172a 0%, #1e1b4b 100%)',
      }}
    >
      <BookOpen className="h-10 w-10 text-indigo-400 opacity-60" aria-hidden />
      <div>
        <p className="text-lg font-bold text-white">{material.title}</p>
        {material.organization && (
          <p className="text-xs text-indigo-300 mt-1">{material.organization}</p>
        )}
      </div>
      <p className="text-xs text-indigo-400 italic leading-relaxed max-w-[200px]">
        "Those who wait on the Lord shall renew their strength."
      </p>
    </div>
  )
}

// ─── Main FlipBookViewer ──────────────────────────────────────────────────────

export interface FlipBookViewerProps {
  slug: string
  studyMaterial: StudyMaterial
}

export function FlipBookViewer({ slug, studyMaterial }: FlipBookViewerProps) {
  const pages = useMemo(() => buildPages(studyMaterial), [studyMaterial])
  const totalPages = pages.length

  // ── State ──
  const [currentPage, setCurrentPage] = useState(0)
  const [fontSize, setFontSize] = useState(14)   // px, range 10–20
  const answersRef = useRef<AnswerMap>({})
  const [mounted, setMounted] = useState(false)

  // Scripture modal state
  type ModalSection = StudySection | null
  const [modalSection, setModalSection] = useState<ModalSection>(null)

  // ── Book ref ──
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const bookRef = useRef<any>(null)

  // Expose to window for debugging
  useEffect(() => {
    if (typeof window !== 'undefined') {
      ;(window as any).bookRef = bookRef
      ;(window as any).goPrev = goPrev
      ;(window as any).goNext = goNext
    }
  })

  // ── Mount guard (react-pageflip uses DOM APIs) ──
  useEffect(() => setMounted(true), [])

  // ── Rehydrate answers from localStorage ──
  useEffect(() => {
    try {
      const raw = localStorage.getItem(storageKey(slug))
      if (raw) answersRef.current = JSON.parse(raw) as AnswerMap
    } catch { /* ignore */ }
  }, [slug])

  // Helper to persist without rendering
  const saveAnswers = () => {
    try {
      localStorage.setItem(storageKey(slug), JSON.stringify(answersRef.current))
    } catch { /* ignore */ }
  }

  // ── Answer handlers (Uncontrolled to prevent re-render) ──
  const handleStringAnswer = useCallback((id: string, value: string) => {
    answersRef.current[id] = value
    saveAnswers()
  }, [slug])

  const handleCheckboxToggle = useCallback(
    (id: string, option: string, checked: boolean) => {
      const current = (answersRef.current[id] as string[]) ?? []
      answersRef.current[id] = checked 
        ? [...current, option] 
        : current.filter((v) => v !== option)
      saveAnswers()
    },
    [slug]
  )

  // ── Font size ──
  const MIN_FONT = 10
  const MAX_FONT = 20
  function biggerFont() { setFontSize((f) => Math.min(MAX_FONT, f + 1)) }
  function smallerFont() { setFontSize((f) => Math.max(MIN_FONT, f - 1)) }

  // ── Navigation ──
  function goNext() {
    bookRef.current?.pageFlip()?.flipNext()
  }
  
  function goPrev() {
    bookRef.current?.pageFlip()?.flipPrev()
  }

  // ── Reset ──
  function clearAnswers() {
    if (!window.confirm('Clear all your answers for this guide?')) return
    answersRef.current = {}
    localStorage.removeItem(storageKey(slug))
    window.location.reload() // Force reload since we are fully uncontrolled
  }

  // ── Render a page's inner content ──
  function renderPageContent(page: PageData): React.ReactNode {
    switch (page.kind) {
      case 'cover':
        return <CoverContent material={page.material} />
      case 'section-header':
        return (
          <SectionHeaderContent
            section={page.section}
            sectionIdx={page.sectionIdx}
            total={page.total}
            onOpenModal={() => setModalSection(page.section)}
          />
        )
      case 'questions':
        return (
          <QuestionsPageContent
            section={page.section}
            sectionIdx={page.sectionIdx}
            questions={page.questions}
            partNum={page.partNum}
            totalParts={page.totalParts}
            answersRef={answersRef}
            onStringAnswer={handleStringAnswer}
            onCheckboxToggle={handleCheckboxToggle}
          />
        )
      case 'blank':
        return (
          <div className="h-full flex items-center justify-center">
            <div className="h-8 w-8 rounded-full border border-gray-100" />
          </div>
        )
      case 'back':
        return <BackContent material={page.material} />
    }
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // PRINT layout — simple stacked, no flipbook
  // ─────────────────────────────────────────────────────────────────────────────

  const PrintLayout = () => (
    <div className="hidden print:block p-8">
      <h1 className="text-2xl font-bold">{studyMaterial.title}</h1>
      {studyMaterial.subtitle && <p className="text-gray-600">{studyMaterial.subtitle}</p>}
      {studyMaterial.memory_verse && (
        <blockquote className="mt-3 border-l-4 border-indigo-400 pl-4 italic text-sm text-gray-700">
          {studyMaterial.memory_verse}
        </blockquote>
      )}
      {studyMaterial.study_sections.map((section, si) => (
        <div key={section.id} className="mt-8 break-before-page">
          <h2 className="text-lg font-bold">{section.title}</h2>
          {section.scripture_reference && (
            <p className="text-sm italic text-gray-500">{section.scripture_reference}</p>
          )}
          <div className="mt-4 space-y-4">
            {section.questions.map((q) => (
              <div key={q.id}>
                <p className="text-sm font-medium">{q.prompt}</p>
                <div className="mt-1 rounded border border-gray-300 min-h-[40px] px-2 py-1 text-sm text-gray-700">
                  {answersRef.current[q.id]
                    ? Array.isArray(answersRef.current[q.id])
                      ? (answersRef.current[q.id] as string[]).join(', ')
                      : (answersRef.current[q.id] as string)
                    : ''}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  )

  // ─────────────────────────────────────────────────────────────────────────────

  return (
    <div className="flex flex-col h-screen bg-gradient-to-b from-slate-100 to-slate-200 print:bg-white">

      {/* ── Top bar ── */}
      <header className="flex-shrink-0 flex items-center justify-between px-4 py-2.5 bg-white/80 backdrop-blur-sm border-b border-gray-200 print:hidden">
        <div className="min-w-0">
          <h1 className="text-sm font-bold text-gray-900 truncate">{studyMaterial.title}</h1>
          {studyMaterial.organization && (
            <p className="text-xs text-gray-400 truncate">{studyMaterial.organization}</p>
          )}
        </div>
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <button
            type="button"
            onClick={clearAnswers}
            title="Reset answers"
            className="inline-flex items-center gap-1 rounded-lg border border-gray-200 px-2 py-1 text-xs text-gray-500 hover:text-red-500 hover:border-red-200 transition-colors"
          >
            <RotateCcw className="h-3 w-3" />
            Reset
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-1 rounded-lg border border-indigo-200 bg-indigo-50 px-2 py-1 text-xs font-medium text-indigo-700 hover:bg-indigo-100 transition-colors"
          >
            <Printer className="h-3 w-3" />
            PDF
          </button>
        </div>
      </header>

      {/* ── Book stage ── */}
      <div
        className="relative flex-1 flex flex-col items-center justify-center overflow-hidden print:hidden px-10"
        style={{ fontSize: `${fontSize}px` }}
      >

        {mounted ? (
          <HTMLFlipBook
            ref={bookRef}
            width={330}
            height={500}
            size="stretch"
            minWidth={280}
            maxWidth={420}
            minHeight={400}
            maxHeight={580}
            drawShadow
            flippingTime={700}
            usePortrait
            mobileScrollSupport={true}
            clickEventForward={false}
            useMouseEvents={true}
            showPageCorners={true}
            disableFlipByClick={true}
            maxShadowOpacity={0.4}
            className="shadow-2xl"
            style={{}}
            startPage={0}
            startZIndex={0}
            autoSize
            swipeDistance={60}
            renderOnlyPageLengthChange={true}
            onFlip={(e) => setCurrentPage(e.data)}
          >
            {pages.map((page, idx) => {
              const isCover = page.kind === 'cover'
              const isBack = page.kind === 'back'
              const showNum = !isCover && !isBack && page.kind !== 'blank'
              return (
                <Page
                  key={idx}
                  density="soft"
                  pageNum={showNum ? idx : undefined}
                  totalPages={totalPages}
                >
                  {renderPageContent(page)}
                </Page>
              )
            })}
          </HTMLFlipBook>
        ) : (
          // Pre-mount skeleton
          <div className="w-[330px] h-[500px] rounded-lg bg-white shadow-2xl animate-pulse" />
        )}
      </div>

      {/* ── Bottom nav ── */}
      <nav className="flex-shrink-0 flex items-center justify-between px-6 py-3 bg-white/80 backdrop-blur-sm border-t border-gray-200 print:hidden">
        <button
          type="button"
          onClick={goPrev}
          disabled={currentPage === 0}
          aria-label="Previous page"
          className="inline-flex items-center gap-1 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors px-4 py-1.5 text-sm font-medium text-gray-600"
        >
          <ChevronLeft className="h-4 w-4" />
          Prev
        </button>

        <span className="text-xs text-gray-400 font-medium">
          {currentPage + 1} / {totalPages}
        </span>

        {/* ── Font size controls ── */}
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={smallerFont}
            disabled={fontSize <= MIN_FONT}
            aria-label="Decrease font size"
            title="Decrease font size"
            className="inline-flex items-center justify-center w-8 h-8 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors text-sm font-bold text-gray-600 leading-none"
          >
            A<span className="text-[9px] align-super">−</span>
          </button>
          <button
            type="button"
            onClick={biggerFont}
            disabled={fontSize >= MAX_FONT}
            aria-label="Increase font size"
            title="Increase font size"
            className="inline-flex items-center justify-center w-8 h-8 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors text-base font-bold text-gray-600 leading-none"
          >
            A<span className="text-[9px] align-super">+</span>
          </button>
        </div>

        <button
          type="button"
          onClick={goNext}
          disabled={currentPage >= totalPages - 1}
          aria-label="Next page"
          className="inline-flex items-center gap-1 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors px-4 py-1.5 text-sm font-medium text-gray-600"
        >
          Next
          <ChevronRight className="h-4 w-4" />
        </button>
      </nav>

      {/* ── Print layout ── */}
      <PrintLayout />

      {/* ── Scripture modal ── */}
      {modalSection && (
        <ScriptureModal
          sectionTitle={modalSection.title}
          scriptureReference={modalSection.scripture_reference}
          summary={modalSection.summary}
          scriptureText={modalSection.scripture_text}
          onClose={() => setModalSection(null)}
        />
      )}
    </div>
  )
}
